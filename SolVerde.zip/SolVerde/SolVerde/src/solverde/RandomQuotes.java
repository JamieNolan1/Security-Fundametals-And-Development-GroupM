/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solverde;

/**
 *
 * @author jamie
 */
public class RandomQuotes {
    // Declare the quote string
    private String quote;

    // Constructor to initialize the randomQuotes
    public RandomQuotes(String quote) {
        this.quote = quote;  
    }

    // Getter method to retrieve the quote
    public String getQuote() {
        return quote;
    }
    
}
