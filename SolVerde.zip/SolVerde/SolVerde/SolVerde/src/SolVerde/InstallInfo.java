/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solverde;

/**
 *
 * @author danma
 */
public class InstallInfo {
    private String info;
    
    public InstallInfo(String info) {
        this.info = info;
    }
    
    public String getInfo() {
        return info;
    }
}
